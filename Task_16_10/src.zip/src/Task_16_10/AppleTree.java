package Task_16_10;

class AppleTree extends GardenTree {
    private static final long serialVersionUID = -3949314371553731193L;
    public AppleTree(int age, boolean isFruitBearing) {
        super("Apple Tree", age, isFruitBearing);
    }
}
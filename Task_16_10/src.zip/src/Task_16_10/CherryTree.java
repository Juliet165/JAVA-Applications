package Task_16_10;

class CherryTree extends GardenTree {
	private static final long serialVersionUID = 2765106927816125373L;
    public CherryTree(int age, boolean isFruitBearing) {
        super("Cherry Tree", age, isFruitBearing);
    }
}
package Task_16_10;

class PearTree extends GardenTree {
    public PearTree(int age, boolean isFruitBearing) {
    	super("Pear Tree", age, isFruitBearing);
    }
}
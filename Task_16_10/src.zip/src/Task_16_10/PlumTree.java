package Task_16_10;


class PlumTree extends GardenTree {
    public PlumTree(int age, boolean isFruitBearing) {
    	super("Plum Tree", age, isFruitBearing);
    }
}
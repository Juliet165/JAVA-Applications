package Task_09_10;

import java.util.Arrays;

public class Tests {

	public static void main(String[] args) {
		Rational[] rationals = {
	            new Rational(1, 2),
	            new Rational(3, 4),
	            new Rational(1, 3),
	            new Rational(2, 5),
	    };

		System.out.println("Исходный массив:");
        for (Rational r : rationals) {
            System.out.println(r);
        }

        Arrays.sort(rationals); 
        System.out.println("\nОтсортированный массив:");
        for (Rational r : rationals) {
            System.out.println(r);
        }

        String rationalString = "5/6";
        Rational r = Rational.fromString(rationalString);
        System.out.println("\nRational из строки: " + r);
        System.out.println("\nИтератор по Rational(1/2):");
        for (int value : new Rational(1, 2)) {
            System.out.println(value);
        }

	}

}
